PDB: 6b08
MAP: EMD_7120
Stem residue 1: 183:B
Stem residue 1: 199:B
Fragment sequence: IEHGADIRAQDSLGNT
Resolution: 3.6

First Hit saved
