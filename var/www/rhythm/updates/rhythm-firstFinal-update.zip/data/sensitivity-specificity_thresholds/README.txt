The files contain in each row the specificity, the corresponding sensitivity and the threshold/cutoff-value used in the prediction.

columns:
1: threshold
2: sensitivity
3: specificity
